<?php
	// ไฟล์ date.php
    echo  date("H:i:s");
?>